/**********************************************************************
 * 
 * Code generated automatically by DirectJNgine
 * Copyright (c) 2009, Pedro Agulló Soliveres
 * 
 * DO NOT MODIFY MANUALLY!!
 * 
 **********************************************************************/

Ext.namespace( 'NX.direct.api');
Ext.namespace( 'NX.direct');

NX.direct.api.PROVIDER_BASE_URL=window.location.protocol + '//' + window.location.host + '/' + (window.location.pathname.split('/').length>2 ? window.location.pathname.replace(/^\/|\/$/g, '') + '/' : '')  + 'service/extdirect';

NX.direct.api.POLLING_URLS = {
  rapture_State_get : NX.direct.api.PROVIDER_BASE_URL + '/poll/rapture_State_get' /* () => java.util.Map -- calls org.sonatype.nexus.rapture.internal.state.StateComponent.getState */, 
  coreui_Repository_readStatus : NX.direct.api.PROVIDER_BASE_URL + '/poll/coreui_Repository_readStatus' /* () => java.util.List -- calls org.sonatype.nexus.coreui.RepositoryComponent.readStatus */
}

NX.direct.api.REMOTING_API = {
  url: NX.direct.api.PROVIDER_BASE_URL,
  type: 'remoting',
  namespace: NX.direct,
  actions: {
    capability_Capability: [
      {
        name: 'read'/*() => java.util.List */,
        len: 0,
        formHandler: false
      },
      {
        name: 'disable'/*(String) => void */,
        len: 1,
        formHandler: false
      },
      {
        name: 'enable'/*(String) => void */,
        len: 1,
        formHandler: false
      },
      {
        name: 'updateNotes'/*(org.sonatype.nexus.coreui.internal.capability.CapabilityNotesXO) => org.sonatype.nexus.coreui.internal.capability.CapabilityXO */,
        len: 1,
        formHandler: false
      },
      {
        name: 'update'/*(org.sonatype.nexus.coreui.internal.capability.CapabilityXO) => org.sonatype.nexus.coreui.internal.capability.CapabilityXO */,
        len: 1,
        formHandler: false
      },
      {
        name: 'create'/*(org.sonatype.nexus.coreui.internal.capability.CapabilityXO) => org.sonatype.nexus.coreui.internal.capability.CapabilityXO */,
        len: 1,
        formHandler: false
      },
      {
        name: 'readTypes'/*() => java.util.List */,
        len: 0,
        formHandler: false
      },
      {
        name: 'remove'/*(String) => void */,
        len: 1,
        formHandler: false
      }
    ],
    coreui_Webhook: [
      {
        name: 'listWithTypeRepository'/*() => java.util.List */,
        len: 0,
        formHandler: false
      },
      {
        name: 'listWithTypeGlobal'/*() => java.util.List */,
        len: 0,
        formHandler: false
      }
    ],
    coreui_Role: [
      {
        name: 'readFromSource'/*(String) => java.util.List */,
        len: 1,
        formHandler: false
      },
      {
        name: 'read'/*() => java.util.List */,
        len: 0,
        formHandler: false
      },
      {
        name: 'readReferences'/*() => java.util.List */,
        len: 0,
        formHandler: false
      },
      {
        name: 'readSources'/*() => java.util.List */,
        len: 0,
        formHandler: false
      },
      {
        name: 'update'/*(org.sonatype.nexus.api.extdirect.common.security.role.model.RoleXO) => org.sonatype.nexus.api.extdirect.common.security.role.model.RoleXO */,
        len: 1,
        formHandler: false
      },
      {
        name: 'create'/*(org.sonatype.nexus.api.extdirect.common.security.role.model.RoleXO) => org.sonatype.nexus.api.extdirect.common.security.role.model.RoleXO */,
        len: 1,
        formHandler: false
      },
      {
        name: 'remove'/*(String) => void */,
        len: 1,
        formHandler: false
      }
    ],
    rapture_State: [
    ],
    firewall_RepositoryStatus: [
      {
        name: 'read'/*() => java.util.List */,
        len: 0,
        formHandler: false
      },
      {
        name: 'readCapabilitiesStatus'/*(String) => Boolean */,
        len: 1,
        formHandler: false
      }
    ],
    coreui_Blobstore: [
      {
        name: 'readNoneGroupEntriesIncludingEntryForAll'/*() => java.util.List */,
        len: 0,
        formHandler: false
      },
      {
        name: 'readGroups'/*() => java.util.List */,
        len: 0,
        formHandler: false
      },
      {
        name: 'read'/*() => java.util.List */,
        len: 0,
        formHandler: false
      },
      {
        name: 'readQuotaTypes'/*() => java.util.List */,
        len: 0,
        formHandler: false
      },
      {
        name: 'readWithAll'/*() => java.util.List */,
        len: 0,
        formHandler: false
      },
      {
        name: 'readNames'/*() => java.util.List */,
        len: 0,
        formHandler: false
      },
      {
        name: 'defaultWorkDirectory'/*() => org.sonatype.nexus.coreui.PathSeparatorXO */,
        len: 0,
        formHandler: false
      },
      {
        name: 'readGroupable'/*(org.sonatype.nexus.extdirect.model.StoreLoadParameters) => java.util.List */,
        len: 1,
        formHandler: false
      },
      {
        name: 'update'/*(org.sonatype.nexus.coreui.BlobStoreXO) => org.sonatype.nexus.coreui.BlobStoreXO */,
        len: 1,
        formHandler: false
      },
      {
        name: 'create'/*(org.sonatype.nexus.coreui.BlobStoreXO) => org.sonatype.nexus.coreui.BlobStoreXO */,
        len: 1,
        formHandler: false
      },
      {
        name: 'readTypes'/*() => java.util.List */,
        len: 0,
        formHandler: false
      },
      {
        name: 'remove'/*(String) => void */,
        len: 1,
        formHandler: false
      }
    ],
    coreui_Browse: [
      {
        name: 'read'/*(org.sonatype.nexus.api.extdirect.common.repository.browse.model.TreeStoreLoadParameters) => java.util.List */,
        len: 1,
        formHandler: false
      }
    ],
    coreui_Component: [
      {
        name: 'readAsset'/*(String, String) => org.sonatype.nexus.coreui.AssetXO */,
        len: 2,
        formHandler: false
      },
      {
        name: 'canDeleteAsset'/*(String, String) => boolean */,
        len: 2,
        formHandler: false
      },
      {
        name: 'deleteFolder'/*(String, String) => void */,
        len: 2,
        formHandler: false
      },
      {
        name: 'canDeleteComponent'/*(String) => boolean */,
        len: 1,
        formHandler: false
      },
      {
        name: 'readComponentAssets'/*(org.sonatype.nexus.extdirect.model.StoreLoadParameters) => java.util.List */,
        len: 1,
        formHandler: false
      },
      {
        name: 'deleteComponent'/*(String) => java.util.Set */,
        len: 1,
        formHandler: false
      },
      {
        name: 'canDeleteFolder'/*(String, String) => boolean */,
        len: 2,
        formHandler: false
      },
      {
        name: 'previewAssets'/*(org.sonatype.nexus.extdirect.model.StoreLoadParameters) => org.sonatype.nexus.extdirect.model.PagedResponse */,
        len: 1,
        formHandler: false
      },
      {
        name: 'deleteAsset'/*(String, String) => java.util.Set */,
        len: 2,
        formHandler: false
      },
      {
        name: 'readComponent'/*(String, String) => org.sonatype.nexus.coreui.ComponentXO */,
        len: 2,
        formHandler: false
      }
    ],
    coreui_Task: [
      {
        name: 'read'/*() => java.util.List */,
        len: 0,
        formHandler: false
      },
      {
        name: 'stop'/*(String) => void */,
        len: 1,
        formHandler: false
      },
      {
        name: 'update'/*(org.sonatype.nexus.api.extdirect.common.tasks.TaskXO) => org.sonatype.nexus.api.extdirect.common.tasks.TaskXO */,
        len: 1,
        formHandler: false
      },
      {
        name: 'create'/*(org.sonatype.nexus.api.extdirect.common.tasks.TaskXO) => org.sonatype.nexus.api.extdirect.common.tasks.TaskXO */,
        len: 1,
        formHandler: false
      },
      {
        name: 'readTypes'/*() => java.util.List */,
        len: 0,
        formHandler: false
      },
      {
        name: 'run'/*(String) => void */,
        len: 1,
        formHandler: false
      },
      {
        name: 'remove'/*(String) => void */,
        len: 1,
        formHandler: false
      }
    ],
    s3_S3: [
      {
        name: 'regions'/*() => java.util.List */,
        len: 0,
        formHandler: false
      },
      {
        name: 'encryptionTypes'/*() => java.util.List */,
        len: 0,
        formHandler: false
      }
    ],
    outreach_Outreach: [
      {
        name: 'readStatus'/*() => String */,
        len: 0,
        formHandler: false
      },
      {
        name: 'getProxyDownloadNumbers'/*() => String */,
        len: 0,
        formHandler: false
      }
    ],
    coreui_Upload: [
      {
        name: 'getUploadDefinitions'/*() => java.util.Collection */,
        len: 0,
        formHandler: false
      }
    ],
    healthcheck_Info: [
      {
        name: 'read'/*(com.sonatype.nexus.plugins.healthcheck.ui.HealthCheckXO[]) => java.util.List */,
        len: 1,
        formHandler: false
      }
    ],
    coreui_ProprietaryRepositories: [
      {
        name: 'read'/*() => org.sonatype.nexus.coreui.ProprietaryRepositoriesXO */,
        len: 0,
        formHandler: false
      },
      {
        name: 'readPossibleRepos'/*() => java.util.List */,
        len: 0,
        formHandler: false
      },
      {
        name: 'update'/*(org.sonatype.nexus.coreui.ProprietaryRepositoriesXO) => org.sonatype.nexus.coreui.ProprietaryRepositoriesXO */,
        len: 1,
        formHandler: false
      }
    ],
    coreui_User: [
      {
        name: 'read'/*(org.sonatype.nexus.extdirect.model.StoreLoadParameters) => java.util.List */,
        len: 1,
        formHandler: false
      },
      {
        name: 'get'/*(String, String) => org.sonatype.nexus.api.extdirect.common.security.user.model.UserXO */,
        len: 2,
        formHandler: false
      },
      {
        name: 'readSources'/*() => java.util.List */,
        len: 0,
        formHandler: false
      },
      {
        name: 'update'/*(org.sonatype.nexus.api.extdirect.common.security.user.model.UserXO) => org.sonatype.nexus.api.extdirect.common.security.user.model.UserXO */,
        len: 1,
        formHandler: false
      },
      {
        name: 'create'/*(org.sonatype.nexus.api.extdirect.common.security.user.model.UserXO) => org.sonatype.nexus.api.extdirect.common.security.user.model.UserXO */,
        len: 1,
        formHandler: false
      },
      {
        name: 'updateRoleMappings'/*(org.sonatype.nexus.api.extdirect.common.security.user.model.UserRoleMappingsXO) => org.sonatype.nexus.api.extdirect.common.security.user.model.UserXO */,
        len: 1,
        formHandler: false
      },
      {
        name: 'remove'/*(String, String) => void */,
        len: 2,
        formHandler: false
      },
      {
        name: 'changePassword'/*(String, String, String) => void */,
        len: 3,
        formHandler: false
      }
    ],
    coreui_Selector: [
      {
        name: 'read'/*() => java.util.List */,
        len: 0,
        formHandler: false
      },
      {
        name: 'readReferences'/*() => java.util.List */,
        len: 0,
        formHandler: false
      },
      {
        name: 'update'/*(org.sonatype.nexus.api.extdirect.common.selector.model.SelectorXO) => org.sonatype.nexus.api.extdirect.common.selector.model.SelectorXO */,
        len: 1,
        formHandler: false
      },
      {
        name: 'create'/*(org.sonatype.nexus.api.extdirect.common.selector.model.SelectorXO) => org.sonatype.nexus.api.extdirect.common.selector.model.SelectorXO */,
        len: 1,
        formHandler: false
      },
      {
        name: 'remove'/*(String) => void */,
        len: 1,
        formHandler: false
      }
    ],
    coreui_HttpSettings: [
      {
        name: 'read'/*() => org.sonatype.nexus.coreui.HttpSettingsXO */,
        len: 0,
        formHandler: false
      },
      {
        name: 'update'/*(org.sonatype.nexus.coreui.HttpSettingsXO) => org.sonatype.nexus.coreui.HttpSettingsXO */,
        len: 1,
        formHandler: false
      }
    ],
    rapture_Security: [
      {
        name: 'authenticate'/*(String, String) => org.sonatype.nexus.rapture.internal.security.UserXO */,
        len: 2,
        formHandler: false
      },
      {
        name: 'getUser'/*() => org.sonatype.nexus.rapture.internal.security.UserXO */,
        len: 0,
        formHandler: false
      },
      {
        name: 'getPermissions'/*() => java.util.List */,
        len: 0,
        formHandler: false
      },
      {
        name: 'authenticationToken'/*(String, String) => String */,
        len: 2,
        formHandler: false
      }
    ],
    coreui_Search: [
      {
        name: 'read'/*(org.sonatype.nexus.extdirect.model.StoreLoadParameters) => org.sonatype.nexus.extdirect.model.LimitedPagedResponse */,
        len: 1,
        formHandler: false
      }
    ],
    healthcheck_Status: [
      {
        name: 'read'/*() => java.util.List */,
        len: 0,
        formHandler: false
      },
      {
        name: 'enableAll'/*(boolean) => void */,
        len: 1,
        formHandler: false
      },
      {
        name: 'update'/*(boolean, String, boolean) => com.sonatype.nexus.plugins.healthcheck.ui.HealthCheckRepositoryStatusXO */,
        len: 3,
        formHandler: false
      },
      {
        name: 'readForRepository'/*(String) => com.sonatype.nexus.plugins.healthcheck.ui.HealthCheckRepositoryStatusXO */,
        len: 1,
        formHandler: false
      }
    ],
    coreui_AnonymousSettings: [
      {
        name: 'read'/*() => org.sonatype.nexus.coreui.AnonymousSettingsXO */,
        len: 0,
        formHandler: false
      },
      {
        name: 'update'/*(org.sonatype.nexus.coreui.AnonymousSettingsXO) => org.sonatype.nexus.coreui.AnonymousSettingsXO */,
        len: 1,
        formHandler: false
      }
    ],
    coreui_Privilege: [
      {
        name: 'read'/*(org.sonatype.nexus.extdirect.model.StoreLoadParameters) => org.sonatype.nexus.extdirect.model.PagedResponse */,
        len: 1,
        formHandler: false
      },
      {
        name: 'readReferences'/*() => java.util.List */,
        len: 0,
        formHandler: false
      },
      {
        name: 'update'/*(org.sonatype.nexus.coreui.PrivilegeXO) => org.sonatype.nexus.coreui.PrivilegeXO */,
        len: 1,
        formHandler: false
      },
      {
        name: 'create'/*(org.sonatype.nexus.coreui.PrivilegeXO) => org.sonatype.nexus.coreui.PrivilegeXO */,
        len: 1,
        formHandler: false
      },
      {
        name: 'readTypes'/*() => java.util.List */,
        len: 0,
        formHandler: false
      },
      {
        name: 'remove'/*(String) => void */,
        len: 1,
        formHandler: false
      }
    ],
    coreui_Datastore: [
      {
        name: 'read'/*() => java.util.List */,
        len: 0,
        formHandler: false
      },
      {
        name: 'readH2'/*() => java.util.List */,
        len: 0,
        formHandler: false
      }
    ],
    ldap_LdapServer: [
      {
        name: 'verifyLogin'/*(com.sonatype.nexus.ldap.internal.ui.LdapServerXO, String, String) => void */,
        len: 3,
        formHandler: false
      },
      {
        name: 'verifyConnection'/*(com.sonatype.nexus.ldap.internal.ui.LdapServerConnectionXO) => void */,
        len: 1,
        formHandler: false
      },
      {
        name: 'verifyUserMapping'/*(com.sonatype.nexus.ldap.internal.ui.LdapServerXO) => java.util.Collection */,
        len: 1,
        formHandler: false
      },
      {
        name: 'read'/*() => java.util.List */,
        len: 0,
        formHandler: false
      },
      {
        name: 'readTemplates'/*() => java.util.List */,
        len: 0,
        formHandler: false
      },
      {
        name: 'readReferences'/*() => java.util.List */,
        len: 0,
        formHandler: false
      },
      {
        name: 'update'/*(com.sonatype.nexus.ldap.internal.ui.LdapServerXO) => com.sonatype.nexus.ldap.internal.ui.LdapServerXO */,
        len: 1,
        formHandler: false
      },
      {
        name: 'create'/*(com.sonatype.nexus.ldap.internal.ui.LdapServerXO) => com.sonatype.nexus.ldap.internal.ui.LdapServerXO */,
        len: 1,
        formHandler: false
      },
      {
        name: 'clearCache'/*() => void */,
        len: 0,
        formHandler: false
      },
      {
        name: 'changeOrder'/*(java.util.List) => void */,
        len: 1,
        formHandler: false
      },
      {
        name: 'remove'/*(String) => void */,
        len: 1,
        formHandler: false
      }
    ],
    clm_CLM: [
      {
        name: 'verifyConnection'/*(com.sonatype.nexus.api.extdirect.selfhosted.clm.model.IqConnectionXo) => java.util.List */,
        len: 1,
        formHandler: false
      },
      {
        name: 'read'/*() => com.sonatype.nexus.api.extdirect.selfhosted.clm.model.IqConnectionXo */,
        len: 0,
        formHandler: false
      },
      {
        name: 'update'/*(com.sonatype.nexus.api.extdirect.selfhosted.clm.model.IqConnectionXo) => com.sonatype.nexus.api.extdirect.selfhosted.clm.model.IqConnectionXo */,
        len: 1,
        formHandler: false
      },
      {
        name: 'authTypes'/*() => java.util.List */,
        len: 0,
        formHandler: false
      },
      {
        name: 'readApplications'/*() => java.util.List */,
        len: 0,
        formHandler: false
      }
    ],
    ssl_Certificate: [
      {
        name: 'retrieveFromHost'/*(String, Integer, String) => com.sonatype.nexus.ssl.plugin.internal.ui.CertificateXO */,
        len: 3,
        formHandler: false
      },
      {
        name: 'details'/*(String) => com.sonatype.nexus.ssl.plugin.internal.ui.CertificateXO */,
        len: 1,
        formHandler: false
      }
    ],
    ssl_TrustStore: [
      {
        name: 'read'/*() => java.util.List */,
        len: 0,
        formHandler: false
      },
      {
        name: 'create'/*(String) => com.sonatype.nexus.ssl.plugin.internal.ui.CertificateXO */,
        len: 1,
        formHandler: false
      },
      {
        name: 'remove'/*(String) => void */,
        len: 1,
        formHandler: false
      }
    ],
    coreui_Repository: [
      {
        name: 'readReferencesAddingEntriesForAllFormats'/*(org.sonatype.nexus.extdirect.model.StoreLoadParameters) => java.util.List */,
        len: 1,
        formHandler: false
      },
      {
        name: 'getBrowseableFormats'/*() => java.util.List */,
        len: 0,
        formHandler: false
      },
      {
        name: 'read'/*() => java.util.List */,
        len: 0,
        formHandler: false
      },
      {
        name: 'rebuildIndex'/*(String) => String */,
        len: 1,
        formHandler: false
      },
      {
        name: 'invalidateCache'/*(String) => void */,
        len: 1,
        formHandler: false
      },
      {
        name: 'readReferences'/*(org.sonatype.nexus.extdirect.model.StoreLoadParameters) => java.util.List */,
        len: 1,
        formHandler: false
      },
      {
        name: 'update'/*(org.sonatype.nexus.coreui.RepositoryXO) => org.sonatype.nexus.coreui.RepositoryXO */,
        len: 1,
        formHandler: false
      },
      {
        name: 'create'/*(org.sonatype.nexus.coreui.RepositoryXO) => org.sonatype.nexus.coreui.RepositoryXO */,
        len: 1,
        formHandler: false
      },
      {
        name: 'readFormats'/*() => java.util.List */,
        len: 0,
        formHandler: false
      },
      {
        name: 'readReferencesAddingEntryForAll'/*(org.sonatype.nexus.extdirect.model.StoreLoadParameters) => java.util.List */,
        len: 1,
        formHandler: false
      },
      {
        name: 'readRecipes'/*() => java.util.List */,
        len: 0,
        formHandler: false
      },
      {
        name: 'remove'/*(String) => void */,
        len: 1,
        formHandler: false
      }
    ],
    ClmStateContributor: [
    ],
    cleanup_CleanupPolicy: [
      {
        name: 'readByFormat'/*(org.sonatype.nexus.extdirect.model.StoreLoadParameters) => java.util.List */,
        len: 1,
        formHandler: false
      }
    ],
    coreui_Email: [
      {
        name: 'sendVerification'/*(org.sonatype.nexus.coreui.EmailConfigurationXO, String) => void */,
        len: 2,
        formHandler: false
      },
      {
        name: 'read'/*() => org.sonatype.nexus.coreui.EmailConfigurationXO */,
        len: 0,
        formHandler: false
      },
      {
        name: 'update'/*(org.sonatype.nexus.coreui.EmailConfigurationXO) => org.sonatype.nexus.coreui.EmailConfigurationXO */,
        len: 1,
        formHandler: false
      }
    ],
    node_NodeAccess: [
      {
        name: 'nodes'/*() => java.util.List */,
        len: 0,
        formHandler: false
      }
    ],
    coreui_RealmSettings: [
      {
        name: 'read'/*() => org.sonatype.nexus.coreui.RealmSettingsXO */,
        len: 0,
        formHandler: false
      },
      {
        name: 'update'/*(org.sonatype.nexus.coreui.RealmSettingsXO) => org.sonatype.nexus.coreui.RealmSettingsXO */,
        len: 1,
        formHandler: false
      },
      {
        name: 'readRealmTypes'/*() => java.util.List */,
        len: 0,
        formHandler: false
      }
    ],
    atlas_SystemInformation: [
      {
        name: 'read'/*() => java.util.Map */,
        len: 0,
        formHandler: false
      }
    ],
    rut_Auth: [
      {
        name: 'authenticate'/*() => boolean */,
        len: 0,
        formHandler: false
      },
      {
        name: 'authToken'/*() => String */,
        len: 0,
        formHandler: false
      }
    ]
  }
}

